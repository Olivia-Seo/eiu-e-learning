LetterOpener.configure do |config|
  config.message_template = :default
  # config.message_template = :light
end