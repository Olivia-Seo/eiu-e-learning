require "test_helper"

class EnrollmentMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
