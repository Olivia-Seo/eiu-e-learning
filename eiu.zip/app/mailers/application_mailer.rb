class ApplicationMailer < ActionMailer::Base
  default from: "EIU-E-Learning <support@eiu.com>"
  layout 'mailer'
end

